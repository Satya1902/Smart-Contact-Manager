package com.smart.Entity;

import java.util.ArrayList; 
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	
	@Size(min = 3,max = 15,message = "size of the name should be between 3 to 15 chanters")
	String name;

	@Email
	@Column(unique = true)
	String email;

	String role;
	String password;
	String about;
	
	@OneToMany(cascade = jakarta.persistence.CascadeType.ALL , mappedBy = "user")
	private java.util.List<Contact>contacts= new ArrayList<>();
	
	public User() {
		super();
	}

	public User(@NotBlank(message = "This field can not be empty") String name, String email, String role,
			String password, String about, List<Contact> contacts) {
		super();
		this.name = name;
		this.email = email;
		this.role = role;
		this.password = password;
		this.about = about;
		this.contacts = contacts;
	}

	public User(@NotBlank(message = "This field can not be empty") String name, String email, String password,
			String about, List<com.smart.Entity.Contact> contacts) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.about = about;
		this.contacts = contacts;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public java.util.List<Contact> getContacts() {
		return contacts;
	}

	public void setContacts(java.util.List<Contact> contacts) {
		this.contacts = contacts;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", role=" + role + ", password=" + password
				+ ", about=" + about + ", contacts=" + contacts + "]";
	}

	
}

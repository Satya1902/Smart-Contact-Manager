package com.smart.controller;

import java.util.Random; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.Entity.User;
import com.smart.dao.UserRepository;
import com.smart.helper.Message;
import com.smart.services.EmailSenderService;
import jakarta.servlet.http.HttpSession;

@Controller
public class ForgotController {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	EmailSenderService emailSenderService;
	
	@GetMapping("/forgot")
	public String forgotEmail(Model model) {
		model.addAttribute("title","Forgot Password");
		return "ForgotEmailForm";
	}
	
	@PostMapping("/send-otp")
	public String sendOTP(@RequestParam("email")String email , HttpSession session) {
		 
		//  Generating 4 didgit of OTP  
		
		Random random=new Random(1000);
		int otp=random.nextInt(9999);
		
		String toEmail = email;
		String subject = "SCM : OTP ";
		String body = ""+otp;
		
		try {
			
		    emailSenderService.sendEmail(toEmail, subject, body);
			session.setAttribute("message", new Message("alert-success","OTP has been sent on your registered email !! "));
			session.setAttribute("OldOTP", body);
			session.setAttribute("toEmail", toEmail);
			return "VarifyOTP";
			
		} catch (Exception e) {
			session.setAttribute("message", new Message("alert-danger"," Please enter registered email .."));
			return "ForgotEmailForm";
		}

	}
	
	@PostMapping("/process-otp")
	public String OTPProcessing(@RequestParam("OTP")String OTP, 
			                     HttpSession session) {
		
		String OLDOTP = (String) session.getAttribute("OldOTP");
//		System.out.println("Your old Otp is : "+OLDOTP);
		if(OTP.equals(OLDOTP)) {
			session.setAttribute("message", new Message("alert-success","OTP-Varified successfully !!!!"));
			return "NewPasswordChangeForm";
		}
		else {

			session.setAttribute("message", new Message("alert-danger","OTP was wrong ...."));
	     	return "ForgotEmailForm";
	     	
		}
	}
	
    @PostMapping("/process-NewPassword")
    public String ProcessNewPassword(@RequestParam("password")String password , 
    		                                       HttpSession session) {
    	try {
    		
    		String email =(String) session.getAttribute("toEmail");
        	User user = userRepository.getUserByUserName(email);
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        	System.out.println("Email is : "+email);
    		session.setAttribute("message", new Message("alert-success","Password Has been changed successfully !!!!"));
        	return "redirect:/signin";

			
		} catch (Exception e) {
			e.printStackTrace();
			session.setAttribute("message", new Message("alert-danger","Something went wrong ...."));
	     	return "ForgotEmailForm";
		}
     }

}

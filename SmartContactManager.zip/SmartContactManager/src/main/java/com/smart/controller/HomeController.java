package com.smart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.smart.Entity.User;
import com.smart.dao.ContactRepository;
import com.smart.dao.UserRepository;
import com.smart.helper.Message;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class HomeController {
	
	@Autowired
	UserRepository userRepository;

	@Autowired
	ContactRepository contactRepository;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
//	Home Page
	
	@GetMapping
	public String HomePage(Model model) {
		model.addAttribute("title","Smart Contact Manager");
		return "Home";
	}
	
//	Signup Page
	
	@GetMapping("/signup")
	public String SignupPage(Model model ) {
		model.addAttribute("title","Signup Page");
		User user = new User();
		model.addAttribute("user",user);
		return "Signup";
	}
	
//	Registeration of User in Backend
	
	@PostMapping("/do-register")
	public String registerUser(@Valid @ModelAttribute("user")User user ,
			                   BindingResult result,
			                   HttpSession session,
                               Model model ){

            try {

               user.setRole("ROLE_USER");

               user.setPassword(passwordEncoder.encode(user.getPassword()));

               System.out.println(user);
               
               if(result.hasErrors()) {
               throw new Exception();
               }
               
               userRepository.save(user);
               session.setAttribute("message", new Message("alert-success","You have been registered successfully :)"));
               return "Signin";

               } catch (Exception e) {
               e.printStackTrace();
               session.setAttribute("message", new Message("alert-danger","Something went wrong ......"));
               return "Signup";
               }
	        }
	
//	Signing / Login Page
	
	@GetMapping("/signin")
	public String SignInPage(Model model , HttpSession session) {
		model.addAttribute("title","Signin");
		return "Signin";
	}
	
//	About Page 
	
	@GetMapping("/about")
	public String aboutPage(Model model) {
		model.addAttribute("title","About");
		return "about";
	}
	
}
